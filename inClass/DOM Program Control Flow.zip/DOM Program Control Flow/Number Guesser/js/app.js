var guess = document.getElementById("guess");
var output = document.getElementById("output");
var guessCount = 0;
var correctNumber = Math.floor((Math.random() * 10) + 1);
console.log(correctNumber);

function check() {
    var userGuess = Number(guess.value);
    if (guessCount < 3) {
        if (userGuess>correctNumber) {
            guessCount += 1;
            output.innerHTML = "Your guess is too high.";
        }
        else if (userGuess<correctNumber) {
            guessCount += 1;
            output.innerHTML = "Your guess is too low.";
        }
        else if (userGuess==correctNumber) {
            output.innerHTML = "You guessed the correct number!";
        }
    }
    else {
        output.innerHTML = "You have exceeded the limit of 3 guesses. The correct number was " + correctNumber + ".";
    }
}
