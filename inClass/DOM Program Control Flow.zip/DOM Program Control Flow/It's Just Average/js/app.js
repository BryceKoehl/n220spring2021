var outputSum = document.getElementById("outputSum");
var outputAverage = document.getElementById("outputAverage");
var numbers = [16, 22, 20, 30];
var sum = 0;

for (var i = 0; i < numbers.length; i++) {
    sum+=numbers[i];
}

var average = sum / numbers.length;
outputSum.innerHTML = "The sum of the array is " + sum;
outputAverage.innerHTML = "The average of the array is " + average;